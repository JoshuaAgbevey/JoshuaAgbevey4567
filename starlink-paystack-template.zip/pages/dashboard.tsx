import dynamic from 'next/dynamic';
import { useState } from 'react';

const PaystackButton = dynamic(() => import('react-paystack').then(mod => mod.PaystackButton), { ssr: false });

export default function Dashboard() {
  const publicKey = process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY || '';
  const [email, setEmail] = useState('');
  const amount = 5000 * 100; // in kobo

  const componentProps = {
    email,
    amount,
    metadata: { name: "Starlink User" },
    publicKey,
    text: "Subscribe",
    onSuccess: () => alert("Thanks for subscribing!"),
    onClose: () => alert("Payment closed."),
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6 space-y-4">
      <h1 className="text-3xl font-semibold">Starlink Dashboard</h1>
      <input
        className="border px-4 py-2 rounded w-full max-w-md"
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <PaystackButton {...componentProps} />
    </main>
  );
}
