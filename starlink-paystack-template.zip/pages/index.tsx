import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">Welcome to Starlink</h1>
      <p className="text-lg mb-6">Your satellite control platform.</p>
      <Link href="/dashboard" className="bg-blue-600 text-white px-4 py-2 rounded">
        Go to Dashboard
      </Link>
    </main>
  );
}
